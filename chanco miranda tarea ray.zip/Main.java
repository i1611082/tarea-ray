import java.util.*;
import maps.cordenadas;

class Main {

  public static void maps() {
    ArrayList<cordenadas> lista = new ArrayList<cordenadas>();

    double Latitud, Longitud;
    int nDatos;
    Scanner input = new Scanner(System.in);

    System.out.println("INGRESA TUS DATOS :");
    System.out.println("====================");
    nDatos = input.nextInt();
    
    for (int x = 0; x < nDatos; x++) {
      System.out.println("");
      System.out.println("DATO" + (x + 1));
      System.out.println("");
      System.out.println("Ingrese longitud " + (x + 1));
      Latitud = input.nextDouble();
      System.out.println("Ingrese longitud " + (x + 1));
      Longitud = input.nextDouble();

      cordenadas o = new cordenadas();
      o.lat = Latitud;
      o.lonj = Longitud;

      lista.add(x, o);

    }
    System.out.println("*************************************************");

    System.out.println("https://www.keene.edu/campus/maps/tool/?coordinates=");
    for (int x = 0; x <= nDatos; x++) {
      if (x != nDatos) {
        System.out.print(lista.get(x).lat);
        System.out.print("%2C%20");
        System.out.print(lista.get(x).lonj);
        System.out.print("%0A");
      } else {
        System.out.print(lista.get(0).lat);
        System.out.print("%2C%20");
        System.out.print(lista.get(0).lonj);
      }
    }
  }

  public static void main(String[] args) {
    System.out.println("");
    System.out.println("tarea de un Poligono");
    System.out.println("====================");
    maps();

  }
}