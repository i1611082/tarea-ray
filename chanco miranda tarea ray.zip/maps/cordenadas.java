package maps;
  public class cordenadas{
    public double lat;
    public double lonj;
  }